// ====================================================================
// Cognitive Mirror - Service Worker v1.5.2
// Core features: Badge Management (Blinking), Tab Monitoring, Keep-Alive
// ====================================================================

console.log("[ServiceWorker] Initializing v1.5.2...");

// --- 1. BADGE MANAGER (Re-engineered) ---

const BADGE = {
    RED: '#ef4444',       // Stopped / Error
    GREEN_ON: '#22c55e',  // Recording Active (Bright)
    GREEN_OFF: '#000000', // Blinking state (Dark/Transparent equivalent) - Using Black to simulate 'off' blink or distinct shift
    // User requested "no extra black dot". 
    // If we want a smooth blink, toggling between Green and Light Green is better.
    GREEN_LIGHT: '#86efac',
    TEXT: ' ' // Space to render a dot/square
};

let appState = {
    isRecording: false,
    isPanelOpen: false,
    blinkTimer: null
};

// Safe Badge Setter
const setBadge = (text, color) => {
    try {
        if (chrome.action) {
            // Always set text to ensure background color is visible
            chrome.action.setBadgeText({ text: text });
            chrome.action.setBadgeBackgroundColor({ color: color });
            // Text color white to match most themes, though space makes it invisible
            chrome.action.setBadgeTextColor({ color: '#FFFFFF' }).catch(() => { });
        }
    } catch (e) {
        // Ignore errors (e.g. browser closing)
    }
};

const startBlinking = () => {
    if (appState.blinkTimer) clearInterval(appState.blinkTimer);

    let active = true;
    setBadge(BADGE.TEXT, BADGE.GREEN_ON); // Immediate feedback

    appState.blinkTimer = setInterval(() => {
        // Toggle between Bright Green and Light Green for a "breathing" effect
        // This avoids the "black dot" issue where the text color might interfere
        const color = active ? BADGE.GREEN_LIGHT : BADGE.GREEN_ON;
        setBadge(BADGE.TEXT, color);
        active = !active;
    }, 1000);
};

const stopBlinking = () => {
    if (appState.blinkTimer) {
        clearInterval(appState.blinkTimer);
        appState.blinkTimer = null;
    }
};

const updateBadgeState = () => {
    if (appState.isRecording) {
        // Recording -> Blinking Green
        startBlinking();
    } else {
        // Stopped -> Static Red
        stopBlinking();
        // User requested: "Plugin not open = stopped recording = static red dot"
        setBadge(BADGE.TEXT, BADGE.RED);
    }
};

// Initial State
updateBadgeState();

// --- CLICK HANDLER: OPEN SIDE PANEL ---
chrome.action.onClicked.addListener(async (tab) => {
    try {
        // Open side panel for the current window
        await chrome.sidePanel.open({ windowId: tab.windowId });
        console.log("[ServiceWorker] Side panel opened");
    } catch (e) {
        console.error("[ServiceWorker] Failed to open side panel:", e);
    }
});

// --- 2. TAB MONITORING (Robust) ---

// --- 2. TAB MONITORING (Robust) ---

// Fallback: Use WebNavigation if Tabs API is silent (Common in some environments)
const handleWebNav = async (details) => {
    // Only main frame (frameId 0)
    if (details.frameId === 0 && details.url && details.url.startsWith('http')) {
        console.log(`[ServiceWorker] 🌍 WebNav Event (${details.transitionType || 'history'}): ${details.url}`);

        try {
            const tab = await chrome.tabs.get(details.tabId);
            // REMOVED 'tab.active' check to ensure App receives EVERYTHING even if in background/race condition
            if (tab) {
                processTabUpdate(details.tabId, tab);
            }
        } catch (e) {
            console.error("WebNav tab lookup failed:", e);
        }
    }
};

chrome.webNavigation.onCompleted.addListener(handleWebNav);
chrome.webNavigation.onHistoryStateUpdated.addListener(handleWebNav);

// Extracted processing logic to share between listeners
async function processTabUpdate(tabId, tab) {
    if (!tab) return;
    console.log(`[ServiceWorker] ⚡ Processing Tab ID ${tabId}: ${tab.title?.slice(0, 20)} (${tab.url?.slice(0, 30)}...)`);

    if (!tab.url || !tab.url.startsWith('http')) {
        console.log("[ServiceWorker] ⚠️ Skipped non-http:", tab.url);
        return;
    }

    try {
        // 1. Inject script to get Referrer
        let injection = null;
        try {
            injection = await chrome.scripting.executeScript({
                target: { tabId: tabId },
                func: () => ({
                    referrer: document.referrer,
                    content: document.body?.innerText?.slice(0, 5000) || ''
                })
            });
        } catch (e) {
            console.debug("Script injection failed:", e.message);
        }

        const data = injection?.[0]?.result || { referrer: '', content: '' };

        // 2. Broadcast to Side Panel via Persistent Port (Reliable)
        const msg = {
            type: 'TAB_UPDATED',
            tab: {
                id: tabId,
                title: tab.title,
                url: tab.url,
                favIconUrl: tab.favIconUrl,
                windowId: tab.windowId,
                status: 'complete'
            },
            payload: {
                referrer: data.referrer,
                content: data.content
            }
        };

        if (activeSidePanelPort) {
            // Direct listeners in App.tsx now handle these events.
            // console.log("[ServiceWorker] 📤 Sending TAB_UPDATED via Port");
            // activeSidePanelPort.postMessage(msg);
        } else {
            // console.log("[ServiceWorker] ⚠️ No Active Port. Message dropped.");
            // chrome.runtime.sendMessage(msg).catch(() => { });
        }
        console.log("[ServiceWorker] 📤 Processed Tab Update");
    } catch (e) {
        console.error("[ServiceWorker] Error processing tab:", e);
    }
}

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    // Backup Listener (Keep logging for diagnosis)
    console.log(`[ServiceWorker] onUpdated: ${tabId}, Status: ${changeInfo.status}`);

    if (changeInfo.status === 'complete' && tab.active) {
        processTabUpdate(tabId, tab);
    }
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
    console.log("[ServiceWorker] 👆 Tab Activated:", activeInfo.tabId);
    try {
        const tab = await chrome.tabs.get(activeInfo.tabId);
        if (tab.url && tab.url.startsWith('http')) {
            console.log("[ServiceWorker] 📤 Sending TAB_ACTIVATED to App");
            await chrome.runtime.sendMessage({
                type: 'TAB_ACTIVATED',
                tab: {
                    id: tab.id,
                    title: tab.title,
                    url: tab.url,
                    favIconUrl: tab.favIconUrl,
                    windowId: tab.windowId
                }
            });
        }
    } catch (e) {
        // Tab closed before processing
        console.error("onActivated error", e);
    }
});

// --- 3. COMMUNICATION & STATE CONTROL ---

// --- 5. LIFECYCLE & PERSISTENCE ---

const syncStateFromStorage = async () => {
    try {
        const result = await chrome.storage.local.get(['isRecording']);
        if (result.isRecording !== undefined) {
            appState.isRecording = result.isRecording;
        }
        updateBadgeState();
    } catch (e) {
        // Fallback
    }
};

chrome.runtime.onInstalled.addListener(() => {
    console.log("[ServiceWorker] Installed");
    appState.isRecording = false; // Default off on install
    chrome.storage.local.set({ isRecording: false });
    updateBadgeState();
});

chrome.runtime.onStartup.addListener(() => {
    console.log("[ServiceWorker] Startup");
    syncStateFromStorage();
});

// Also sync on message
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
        case 'RECORDING_STARTED':
            console.log("[ServiceWorker] Recording STARTED");
            appState.isRecording = true;
            chrome.storage.local.set({ isRecording: true });
            updateBadgeState();
            break;

        case 'RECORDING_STOPPED':
            console.log("[ServiceWorker] Recording STOPPED");
            appState.isRecording = false;
            chrome.storage.local.set({ isRecording: false });
            updateBadgeState();
            break;

        case 'PANEL_OPENED':
            appState.isPanelOpen = true;
            // Re-sync state just in case
            syncStateFromStorage();
            break;

        case 'CHECK_BADGE_STATE':
            syncStateFromStorage();
            break;
    }
    return true; // Keep channel open
});
// --- 4. SIDE PANEL ALIVENESS (Fix for "Green Badge when Panel Closed") ---
// Side Panel Port Management
let activeSidePanelPort = null;

chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'sidepanel') {
        console.log("[ServiceWorker] SidePanel Connected");
        appState.isPanelOpen = true;
        activeSidePanelPort = port; // Save reference

        // Sync state on connect
        syncStateFromStorage();

        port.onDisconnect.addListener(() => {
            console.log("[ServiceWorker] SidePanel Disconnected (Closed)");
            appState.isPanelOpen = false;
            activeSidePanelPort = null; // Clear reference

            // Force Stop Recording when Panel Closes
            // Reasoning: The Core Logic (App.tsx) is gone. We cannot record.
            if (appState.isRecording) {
                console.log("[ServiceWorker] Force stopping recording due to panel close");
                appState.isRecording = false;
                chrome.storage.local.set({ isRecording: false });
                updateBadgeState();
            }
        });
    }
});
